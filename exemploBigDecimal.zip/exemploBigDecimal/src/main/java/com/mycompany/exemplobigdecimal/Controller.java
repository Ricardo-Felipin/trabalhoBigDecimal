/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplobigdecimal;

import java.util.ArrayList;

public class Controller {
    private static Controller instancia;
    
    public static ArrayList<ClienteCarro> listaClienteCarro;
    
    public static ArrayList<OS> listaOS;
    
    public static ArrayList<Pecas> listaPecas;
    
    public static ArrayList<Servicos> listaServicos;
      
    public static Controller getInstance(){
        if(instancia == null) {
            return instancia = new Controller();
        }else {
            return instancia;
        }
    }

    private Controller() {
        
        listaClienteCarro = new ArrayList<>();
        listaOS = new ArrayList<>();
        listaPecas = new ArrayList<>();
        listaServicos = new ArrayList<>();     
        
    }
    
    public void salvarPecas(Pecas peca){
        listaPecas.add(peca);
    }
    
        public static ArrayList<Pecas> getListaPecas() {
        return listaPecas;
    }
        
    public void salvarOS(OS os){
        listaOS.add(os);
    }
    public static ArrayList<OS> getListaOS() {
        return listaOS;
    }

    public void salvarClienteCarro(ClienteCarro clientecarro){
        listaClienteCarro.add(clientecarro);
    }
   
    
    public static ArrayList<ClienteCarro> getClienteCarro() {
        return listaClienteCarro;
    }

    public void salvarServicos(Servicos servico){
        listaServicos.add(servico);
    }
    
    public static ArrayList<Servicos> getListaServicos() {
        return listaServicos;
    }
  
}


