/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.exemplobigdecimal;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author aluno
 */
public class FrameCadastro extends javax.swing.JFrame {
    
    private DefaultTableModel modelo = new DefaultTableModel();
    
    private int linhaSelecionada = -1; 
    

   
    public FrameCadastro() {
        initComponents();
        setLocationRelativeTo(this);
   //     carregaTabela();
        carregaTabelaPeca();
    }
    
/*    public void carregaTabela(){
        
        modelo.addColumn("Nome");
        modelo.addColumn("Idade");
        modelo.addColumn("Endereço");
        modelo.addColumn("Telefone");
        modelo.addColumn("Veículo");
        modelo.addColumn("Marca");
        modelo.addColumn("Modelo");
        modelo.addColumn("Ano");
        modelo.addColumn("Placa");
        tbCadastro.setModel(modelo);
        tbCadastro.getColumnModel().
                getColumn(0)
                .setPreferredWidth(10);
        tbCadastro.getColumnModel().getColumn(1).setPreferredWidth(120); 
        
        
        
    }*/
    
        public void carregaTabelaPeca(){
        
        modelo.addColumn("Peça");
        modelo.addColumn("Servico");
        modelo.addColumn("Valor UN");
        modelo.addColumn("Valor");
        modelo.addColumn("Qtde");
        tbServicosPecas.setModel(modelo);
        tbServicosPecas.getColumnModel().
                getColumn(0)
                .setPreferredWidth(10);
        tbServicosPecas.getColumnModel().getColumn(1).setPreferredWidth(120); 
        
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Telefone = new javax.swing.JLabel();
        tfTelefone = new javax.swing.JTextField();
        Nome = new javax.swing.JLabel();
        tfNome = new javax.swing.JTextField();
        btSalvar = new javax.swing.JButton();
        Endereço = new javax.swing.JLabel();
        tfEndereco = new javax.swing.JTextField();
        Idade = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tfVeiculo = new javax.swing.JTextField();
        Veículo = new javax.swing.JLabel();
        tfMarca = new javax.swing.JTextField();
        tfModelo = new javax.swing.JTextField();
        Marca = new javax.swing.JLabel();
        Modelo = new javax.swing.JLabel();
        Ano = new javax.swing.JLabel();
        tfIdade = new javax.swing.JTextField();
        tfAno = new javax.swing.JTextField();
        tfPlaca = new javax.swing.JTextField();
        Ano1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        taDiagnostico = new javax.swing.JTextArea();
        Veículo1 = new javax.swing.JLabel();
        Veículo2 = new javax.swing.JLabel();
        tfDescricaoPeca = new javax.swing.JTextField();
        Veículo3 = new javax.swing.JLabel();
        tfDescricaoServico = new javax.swing.JTextField();
        Veículo4 = new javax.swing.JLabel();
        Veículo5 = new javax.swing.JLabel();
        Veículo6 = new javax.swing.JLabel();
        tfQtde = new javax.swing.JTextField();
        btSalvarServicosPecas = new javax.swing.JButton();
        tfValorUN = new javax.swing.JTextField();
        tfValorServico = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        tbServicosPecas = new javax.swing.JTable();
        btExibir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Ordem de Serviço", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 3, 24))); // NOI18N
        jPanel1.setName(""); // NOI18N

        Telefone.setText("Telefone");

        tfTelefone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfTelefoneActionPerformed(evt);
            }
        });

        Nome.setText("Nome");

        tfNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfNomeActionPerformed(evt);
            }
        });

        btSalvar.setBackground(new java.awt.Color(0, 102, 0));
        btSalvar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btSalvar.setForeground(new java.awt.Color(255, 255, 255));
        btSalvar.setText("Salvar");
        btSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalvarActionPerformed(evt);
            }
        });

        Endereço.setText("Endereço");

        tfEndereco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfEnderecoActionPerformed(evt);
            }
        });

        Idade.setText("Idade");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setText("Informações do Cliente");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setText("Informações do Veículo");

        tfVeiculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfVeiculoActionPerformed(evt);
            }
        });

        Veículo.setText("Veículo");

        tfModelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfModeloActionPerformed(evt);
            }
        });

        Marca.setText("Marca");

        Modelo.setText("Modelo");

        Ano.setText("Ano");

        tfAno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfAnoActionPerformed(evt);
            }
        });

        tfPlaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfPlacaActionPerformed(evt);
            }
        });

        Ano1.setText("Placa");

        taDiagnostico.setColumns(20);
        taDiagnostico.setRows(5);
        jScrollPane2.setViewportView(taDiagnostico);

        Veículo1.setText("Diagnóstico do Problema");

        Veículo2.setText("Serviços");

        tfDescricaoPeca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfDescricaoPecaActionPerformed(evt);
            }
        });

        Veículo3.setText("Peça");

        tfDescricaoServico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfDescricaoServicoActionPerformed(evt);
            }
        });

        Veículo4.setText("Valor");

        Veículo5.setText("Valor UN");

        Veículo6.setText("Qtde");

        tfQtde.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfQtdeActionPerformed(evt);
            }
        });

        btSalvarServicosPecas.setBackground(new java.awt.Color(0, 102, 0));
        btSalvarServicosPecas.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btSalvarServicosPecas.setForeground(new java.awt.Color(255, 255, 255));
        btSalvarServicosPecas.setText("Salvar P&S");
        btSalvarServicosPecas.setActionCommand("Salvar \nPeças/Serviços");
        btSalvarServicosPecas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalvarServicosPecasActionPerformed(evt);
            }
        });

        tfValorUN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfValorUNActionPerformed(evt);
            }
        });

        tfValorServico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfValorServicoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(tfEndereco, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tfNome, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                            .addComponent(Telefone)
                            .addComponent(Endereço)
                            .addComponent(tfTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Nome))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Idade)
                            .addComponent(tfIdade, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(Marca, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Veículo, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tfMarca, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfModelo, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfVeiculo, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Ano1)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(btSalvar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE)
                                .addComponent(tfAno)
                                .addComponent(tfPlaca))
                            .addComponent(Ano))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Veículo1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(tfDescricaoPeca, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tfDescricaoServico, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                        .addComponent(Veículo2, javax.swing.GroupLayout.Alignment.LEADING))
                                    .addComponent(Veículo3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Veículo5)
                                    .addComponent(Veículo4)
                                    .addComponent(tfValorUN, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tfValorServico, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Veículo6)
                            .addComponent(tfQtde, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(Modelo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(btSalvarServicosPecas, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Veículo1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Veículo3)
                            .addComponent(Veículo5)
                            .addComponent(Veículo6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tfDescricaoPeca, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(tfQtde, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tfValorUN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(Veículo2)
                                    .addComponent(Veículo4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(tfDescricaoServico)
                                    .addComponent(tfValorServico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(33, 33, 33))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btSalvarServicosPecas, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(Nome)
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfAno, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfVeiculo, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tfNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tfIdade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Endereço)
                    .addComponent(Marca)
                    .addComponent(Ano1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Telefone)
                    .addComponent(Modelo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btSalvar)))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Veículo)
                    .addComponent(Idade)
                    .addComponent(Ano))
                .addGap(145, 145, 145))
        );

        tbServicosPecas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(tbServicosPecas);

        btExibir.setBackground(new java.awt.Color(0, 153, 153));
        btExibir.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btExibir.setForeground(new java.awt.Color(255, 255, 255));
        btExibir.setText("Exibir OS");
        btExibir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btExibirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 1290, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btExibir, javax.swing.GroupLayout.PREFERRED_SIZE, 1290, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btExibir)
                .addGap(8, 8, 8))
        );

        jPanel1.getAccessibleContext().setAccessibleName("Dados Cliente");
        jPanel1.getAccessibleContext().setAccessibleDescription("Cadastro de Clientes");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tfEnderecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfEnderecoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfEnderecoActionPerformed

    
    
    private void btSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalvarActionPerformed
        String telefone         = tfTelefone.getText();
        String nome             = tfNome.getText();
        String idade            = tfIdade.getText();
        String endereco         = tfEndereco.getText();
        String veiculo          = tfVeiculo.getText();
        String marca            = tfMarca.getText();
        String modelo_carro     = tfModelo.getText();
        String ano              = tfAno.getText();
        String placa            = tfPlaca.getText();
        String diagnostico      = taDiagnostico.getText();

        
        JOptionPane.showMessageDialog(this, "Dados do Cliente e do veiculo salvos com sucesso");
        
        
        ClienteCarro clientecarro = new ClienteCarro();
        clientecarro.setNome(nome);
        clientecarro.setEndereco(endereco);
        clientecarro.setTelefone(telefone);
        clientecarro.setIdade(idade);
        clientecarro.setVeiculo(veiculo);
        clientecarro.setMarca(marca);
        clientecarro.setModelo_Carro(modelo_carro);
        clientecarro.setAno(ano);
        clientecarro.setPlaca(placa);   
        clientecarro.setDiagnostico(diagnostico);
        
        Controller.getInstance().salvarClienteCarro(clientecarro);
        
        
    }//GEN-LAST:event_btSalvarActionPerformed

    private void tfNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfNomeActionPerformed

    private void tfTelefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfTelefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfTelefoneActionPerformed

    private void tfVeiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfVeiculoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfVeiculoActionPerformed

    private void tfAnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfAnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfAnoActionPerformed

    private void tfPlacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfPlacaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfPlacaActionPerformed

    private void tfDescricaoPecaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfDescricaoPecaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfDescricaoPecaActionPerformed

    private void tfDescricaoServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfDescricaoServicoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfDescricaoServicoActionPerformed

    private void tfQtdeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfQtdeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfQtdeActionPerformed

    double valorTotal;
    private void btSalvarServicosPecasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalvarServicosPecasActionPerformed
        
        String peca             = tfDescricaoPeca.getText();
        String servico          = tfDescricaoServico.getText();
        String valorun          = tfValorUN.getText();
        String valorservico     = tfValorServico.getText();
        String quantidade       = tfQtde.getText();

        if(linhaSelecionada >= 0){
            modelo.removeRow((linhaSelecionada));
            modelo.insertRow(linhaSelecionada,new  Object[]{peca,servico,valorun,valorservico,quantidade});
        }else{
            modelo.addRow(new Object[]{peca,servico,valorun,valorservico,quantidade});
        }

        JOptionPane.showMessageDialog(this, "Dados salvos com sucesso");

        tfDescricaoPeca.setText("");
        tfDescricaoServico.setText("");
        tfQtde.setText("");
        tfValorServico.setText("");
        tfValorUN.setText("");
        linhaSelecionada = -1;
        
        double valor = Double.parseDouble(valorservico);
        double valoruni = Double.parseDouble(valorun);
        int qtde = Integer.parseInt(quantidade);
        
        valorTotal = (valoruni * qtde) + valor;
        
        
        Pecas pecas = new Pecas();
        pecas.setPeca(peca);
        pecas.setQuantidade(qtde);
        pecas.setValorUn(valoruni);
        
        
        Controller.getInstance().salvarPecas(pecas);
        
        Servicos servicoa = new Servicos();
        servicoa.setServico(servico);
        servicoa.setValor(valor);
            
        Controller.getInstance().salvarServicos(servicoa);    
        
        
    }//GEN-LAST:event_btSalvarServicosPecasActionPerformed

    private void tfValorUNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfValorUNActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfValorUNActionPerformed

    private void tfValorServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfValorServicoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfValorServicoActionPerformed

    private void tfModeloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfModeloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfModeloActionPerformed

    private void btExibirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btExibirActionPerformed
        
        new FrameOSRelatorio().setVisible(true);
        
    }//GEN-LAST:event_btExibirActionPerformed

/*
    public static void main(String args[]) {
   
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameCadastro().setVisible(true);
            }
        });
    }*/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Ano;
    private javax.swing.JLabel Ano1;
    private javax.swing.JLabel Endereço;
    private javax.swing.JLabel Idade;
    private javax.swing.JLabel Marca;
    private javax.swing.JLabel Modelo;
    private javax.swing.JLabel Nome;
    private javax.swing.JLabel Telefone;
    private javax.swing.JLabel Veículo;
    private javax.swing.JLabel Veículo1;
    private javax.swing.JLabel Veículo2;
    private javax.swing.JLabel Veículo3;
    private javax.swing.JLabel Veículo4;
    private javax.swing.JLabel Veículo5;
    private javax.swing.JLabel Veículo6;
    private javax.swing.JButton btExibir;
    private javax.swing.JButton btSalvar;
    private javax.swing.JButton btSalvarServicosPecas;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTextArea taDiagnostico;
    private javax.swing.JTable tbServicosPecas;
    private javax.swing.JTextField tfAno;
    private javax.swing.JTextField tfDescricaoPeca;
    private javax.swing.JTextField tfDescricaoServico;
    private javax.swing.JTextField tfEndereco;
    private javax.swing.JTextField tfIdade;
    private javax.swing.JTextField tfMarca;
    private javax.swing.JTextField tfModelo;
    private javax.swing.JTextField tfNome;
    private javax.swing.JTextField tfPlaca;
    private javax.swing.JTextField tfQtde;
    private javax.swing.JTextField tfTelefone;
    private javax.swing.JTextField tfValorServico;
    private javax.swing.JTextField tfValorUN;
    private javax.swing.JTextField tfVeiculo;
    // End of variables declaration//GEN-END:variables
}
